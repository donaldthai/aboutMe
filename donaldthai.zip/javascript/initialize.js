/**
 *  Loading defaults at the start of the page 
 */
 
$( document ).ready(function() {
    
    //jquery ui tooltip
    //$( document ).tooltip();
});